/*
--------------------------------------------------------------------------------------------------------------------------------------
ALGORITMA PAPAN SKOR SEPAK BOLA
DIGUNAKAN UNTUK MEMENUHI TUGAS UTS WEB DESIGN

NAMA : NANDA KRISBIANT0
NIM : 3118101095
JURUSAN : D3 MANAJEMEN INFORMATIKA
--------------------------------------------------------------------------------------------------------------------------------------
*/

var skor_a =1;
var skor_b =1;
var tim =[];
//Digunakan untuk menambah dan reset skor tim 1
function goal_a() {
	// body...
	printa.innerHTML = skor_a++;
}
function reset_a(){
	printa.innerHTML = skor_a= 0;
	skor_a=1;
}
//Digunakan untuk menambah dan reset skor tim 2
function goal_b() {
	// body...
	printb.innerHTML = skor_b++;
}
function reset_b(){
	printb.innerHTML = skor_b=0;
	skor_b=1;
}
// Cek User Jika Benar bisa masuk Aplikasi

//Digunakan untuk Memasukan Nama Tim yang akan bertanding	

//START WAKTU PERTANDINGAN
function start(){
	for (var i = 0; i <= 1; i++) {
	var nametim = window.prompt('Masukan Nama Tim');
	tim.push(nametim);
document.getElementById('TEAM1').innerHTML= tim[0];
document.getElementById('TEAM2').innerHTML=tim[1];
	}
txtmenit.innerHTML="0";
info.innerHTML="PERTANDINGAN SEDANG BERLANGSUNG";
var detik = 0;
var menit = 1;
var jalan = setInterval(geser,1000);
function geser() {
if (menit <= 45 || detik < 60){
	if (detik == 60) {
		detik= 0;
		txtmenit.innerHTML=menit++;
	}
detik++;
}
//JIKA SUDAH 45 MENIT OTOMATIS TIMER STOP
else{
	clearInterval(jalan);
	document.getElementById('start_tombol').style.display='block';
	info.innerHTML="PERTANDINGAN USAI";
}
document.getElementById("txtdetik").innerHTML = detik;
}
}
